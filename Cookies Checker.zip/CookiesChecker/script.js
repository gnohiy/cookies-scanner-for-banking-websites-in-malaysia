//To get the website URL
if (typeof document !== 'undefined') {
    chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
     var url = tabs[0].url;
     if(url.length > 50){
      url = url.substring(0,50);
      url += "...";
     }
     document.getElementById("url").innerHTML = url;
    });
}

//To check browser version
if (typeof document !== 'undefined') {
    var versionString = navigator.userAgent;
    var chromeVersion = versionString.match(/Chrome\/(\d+)/);
    const versionElement = document.getElementById("version");
    if (chromeVersion && chromeVersion[1] === "114") {
      versionElement.style.color = "green";
      versionElement.innerHTML = "Chrome " + chromeVersion[1] + " (Up-To-Date)";
    } else if (chromeVersion && chromeVersion[1] < "114") {
      versionElement.style.color = "red";
      versionElement.innerHTML = "Chrome " + chromeVersion[1] + " (Outdated)";
    } else {
      versionElement.innerHTML = "Undefined";
    }
}

//To check website safety
const whiteList = [
  'https://www.maybank2u.com.my/home/m2u/common/login.do',
  'https://www.sc.com/my/bank-with-us/online-banking/',
  'https://onlinebanking.rhbgroup.com/my/login',
  'https://www.hsbc.com.my/',
  'https://rib.affinalways.com/retail/#!/login',
  'https://www.hongleongconnect.com.vn/rib/app/fo/login',
  'https://www.ambank.com.my/eng/online-banking',
  'https://www.cimb.com.my/en/personal/home.html',
  'https://www.citibank.com.my/index.htm',
  'https://www.alliancebank.com.my/',
  'https://www.pbebank.com/',
  'https://www2.irakyat.com.my/personal/login/login.do',
  'https://www.mybsn.com.my/mybsn/login/login.do',
  'https://www.muamalat.com.my/',
  'https://www.bankislam.biz/',
  'https://www.ocbc.com.my/group/gateway',
  'https://pib.uob.com.my/PIBLogin/Public/processPreCapture.do?keyId=lpc&lang=en_MY',
  'https://www.alrajhi24seven.com.my/iportalweb/iRetail@1',
  'https://www.agrobank.com.my/'
];

if (typeof document !== 'undefined') {
  chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
    const currentUrl = tabs[0].url;
    const safeElement = document.getElementById("safeTest");
    if (whiteList.includes(currentUrl)) {
      safeElement.style.color = "green";
      safeElement.innerHTML ="SAFE";
    } else {
      var apiKey = "1c24a830afc9dca67dc46e82e9cea5074c92f0fcccbcebb11003e0286db5c5f1";
      var apiUrl = "https://www.virustotal.com/vtapi/v2/url/report";
      var params = {
        apikey: apiKey,
        resource: currentUrl,
      };
      var xhr = new XMLHttpRequest();
      xhr.open("GET", apiUrl + "?" + encodeParams(params), true);
      xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
          var response = JSON.parse(xhr.responseText);
          if (response.response_code === 1) {
            var positives = response.positives;   
            var safetyStatus = positives > 0 ? "UNSAFE" : "SAFE";
            if (safetyStatus == "SAFE"){
              safeElement.style.color = "green";
            } else{
              safeElement.style.color = "red";
            }
            safeElement.innerHTML = safetyStatus;
          } else {
            safeElement.innerHTML = "Unable to check";
          }
        }
      };
      xhr.send();

      function encodeParams(params) {
        var encoded = [];
        for (var key in params) {
          encoded.push(encodeURIComponent(key) + "=" + encodeURIComponent(params[key]));
        }
        return encoded.join("&");
      }
    }
  });
}

//To set number of cookies
function updateCookiesNum(){
  if (typeof document !== 'undefined') {
    chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
      var checkUrl = tabs[0].url;
      chrome.cookies.getAll({url: checkUrl}, function(cookies) {
      var cookieCount = cookies.length;
      document.getElementById("numOfCookies").innerHTML = cookieCount;
      });
    });
  }
}

updateCookiesNum();

//To create a table displaying all the cookies
if (typeof document !== 'undefined') {
  chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
    var domainUrl = tabs[0].url;
    var cookieTable = document.getElementById("cookies");
    cookieTable.style.display = "table";
    cookieTable.innerHTML = "";
    chrome.cookies.getAll({url: domainUrl}, function(cookies) {
      for(var i in cookies){
        if(i==0){
          var row1 = cookieTable.insertRow(-1);
          row1.insertCell(0).innerHTML = "<strong>Cookie Name</strong>";
          row1.insertCell(1).innerHTML = "<strong>Domain</strong>";
          row1.insertCell(2).innerHTML = "<strong>Sensitive Info</strong>";
          row1.insertCell(3).innerHTML = "<strong>Category</strong>";
          row1.insertCell(4).innerHTML = "<strong>Type</strong>";
        }
        var tableRow = cookieTable.insertRow(-1);
        var cookieName = cookies[i].name;
        var cookieDomain = cookies[i].domain;
        var cookieValue = cookies[i].value;
        var cookieSensitivity = "";
        var sensitiveData = ['password', 'creditcard', 'ssn', 'accountnumber', 'accountbalance', 'transactiondetails', 'pin', 'fullname', 'dob', 'address', 'phone', 'email'];
        var isSensitive = sensitiveData.some(function(type) {
          return cookieName.toLowerCase().includes(type) || cookieValue.toLowerCase().includes(type);
        });
        var cookieCategory = "";
        var isSecure = cookies[i].secure;
        var isHttpOnly = cookies[i].httpOnly;
        var isSameSite = cookies[i].sameSite;
        var type = "";
        if(cookieName.length > 10){
          cookieName = cookieName.substring(0,10);
          cookieName += "...";
        }
        if(cookieDomain.length > 15){
          cookieDomain = cookieDomain.substring(0,15);
          cookieDomain += "...";
        }
        if(isSensitive){
          cookieSensitivity = "Yes";
        } else{
          cookieSensitivity = "No";
        }
        if(cookies[i].sameSite === "None" && cookies[i].secure){
          cookieCategory = "Third-party, secure";
        } else if(cookies[i].sameSite === "None"){
          cookieCategory = "Third-party";
        } else if (cookies[i].secure){
          cookieCategory = "First-party, secure";
        } else{
          cookieCategory = "First-party";
        }
        tableRow.insertCell(0).innerHTML = cookieName;
        tableRow.insertCell(1).innerHTML = cookieDomain;
        tableRow.insertCell(2).innerHTML = cookieSensitivity;
        tableRow.insertCell(3).innerHTML = cookieCategory;
        if(isSecure === false){
          type = "Not Protected";
          const cell = tableRow.insertCell(4);
          cell.style.color = "red";
          cell.innerHTML = type;
        } else if(isHttpOnly === false){
          type = "Not Protected";
          const cell = tableRow.insertCell(4);
          cell.style.color = "red";
          cell.innerHTML = type;
        } else if(isSameSite === "None"){
          type = "Not Protected";
          const cell = tableRow.insertCell(4);
          cell.style.color = "red";
          cell.innerHTML = type;
        } else{
          type = "Protected";
          const cell = tableRow.insertCell(4);
          cell.style.color = "green";
          cell.innerHTML = type;
        }
        const lastRow = tableRow.insertCell(5);
        const removeButton = document.createElement("button");
        removeButton.innerHTML = "Remove";
        removeButton.setAttribute("type", "button");
        removeButton.classList.add("red-button");
        removeButton.addEventListener("click", function(){
          const curRow = this.parentNode.parentNode;
          const cName = curRow.cells[0].innerHTML;
          for(let j = 0; j < cookies.length; j++){
            var dName = cookies[j].name;
            if(cookies[j].name.length > 10){
              cookies[j].name = cookies[j].name.substring(0,10);
              cookies[j].name += "...";
            }
            if(cookies[j].name === cName){
              const curUrl = "http" + (cookies[j].secure ? "s" : "") + "://" + cookies[j].domain + cookies[j].path;
              const confirmed = confirm("Are you sure you want to remove this cookie?");
              if(confirmed){
                cookieTable.deleteRow(curRow.rowIndex);
                chrome.cookies.remove({"url": curUrl, "name": dName});
              }
              updateCookiesNum();
              break;
            }
          }
        });
        lastRow.appendChild(removeButton);
      }

      if(cookieTable.rows.length === 0){
        const emptyRow = cookieTable.insertRow();
        const inCell = emptyRow.insertCell(0);
        inCell.colSpan = 6;
        inCell.textContent = "No Results Found."
      }
    }); 
  });
}

//To download the report
if (typeof document !== 'undefined') {
  const dlButton = document.querySelector('.download');
  dlButton.addEventListener('click', () => {
    html2canvas(document.body).then(canvas => {
     const pdfFile = new jsPDF();
     pdfFile.addImage(canvas.toDataURL('image/jpeg'), 'JPEG', 0, 0, pdfFile.internal.pageSize.width, pdfFile.internal.pageSize.height);
     pdfFile.save('cookiescan.pdf');
   });
  });
}

